import React from 'react';
import { Swiper, SwiperSlide } from 'swiper/react';
import { Pagination } from 'swiper/modules'; 
import { promotions, bestSellers, regularProducts } from './productsData';

import 'swiper/css';
import 'swiper/css/pagination';
import './styles/ProductsPage.css'; 

const ProductsPage = () => {
  
  const ProductCard = ({ image, title, brand, reference, price, stockStatus }: any) => (
    <div className="product-card">
      <div className="product-image-wrapper">
        <img src={image} alt={title} className="product-image" />
        {stockStatus && (
          <span className={`stock-badge ${stockStatus === 'En stock' ? 'en-stock' : 'sur-commande'}`}>
            ✓ {stockStatus}
          </span>
        )}
      </div>
      <div className="product-info">
        {brand && <div className="brand-name">{brand}</div>}
        <a href="#" className="product-title">{title}</a>
        <div className="product-reference">Réf: {reference}</div>
        <div className="product-price">{price} TND</div>
        
        {/* Hover actions */}
        <div className="hover-actions">
          <button className="add-to-cart">Ajouter au panier</button>
          <button className="view-details">
            <i className="fa fa-eye"></i>
          </button>
        </div>
      </div>
    </div>
  );

  const ProductSlider = ({ title, products, className }: any) => (
    <section className="product-section">
      {title && <h2 className={`product-section-title ${className || ''}`}>{title}</h2>}
      <Swiper
        modules={[Pagination]} 
        pagination={{ clickable: true }}
        spaceBetween={30}
        slidesPerView={2}
        breakpoints={{
          768: { slidesPerView: 4 },
        }}
      >
        {products.map((product: any) => (
          <SwiperSlide key={product.id}>
            <ProductCard {...product} />
          </SwiperSlide>
        ))}
      </Swiper>
    </section>
  );

  return (
    <div className="products-container">
      <ProductSlider className="promo" title="Promotions" products={promotions} />
      <ProductSlider title="MEILLEURS VENTES" products={bestSellers} />
      <ProductSlider title="" products={regularProducts} />
    </div>
  );
};

export default ProductsPage;
