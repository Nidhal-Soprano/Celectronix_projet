import React, { useState, useEffect } from 'react';
import './styles/CategoriesCarouselSection.css';

const CategoriesCarouselSection: React.FC = () => {
  const [showCategories, setShowCategories] = useState(false);
  const [currentIndex, setCurrentIndex] = useState(0);

  const images = [
    '/images/slide1.jpg',
    '/images/slide2.jpg',
    '/images/slide3.jpg',
  ];

  const categories = [
    "Cartes De Développement",
    "Robotique",
    "Impression 3D & Accessoires",
    "Tests Et Mesures",
    "Outillage Et Fournitures De Production",
    "Automatisation Industrielle & Électrique",
    "Rétroéclairage TV",
    "Semi-Conducteurs",
    "+ More Categories"
  ];

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentIndex((prevIndex) =>
        prevIndex === images.length - 1 ? 0 : prevIndex + 1
      );
    }, 3000);
    return () => clearInterval(interval);
  }, [images.length]);

  const toggleCategories = () => {
    setShowCategories(!showCategories);
  };

  return (
    <section className="categories-carousel-section">
      <div className="categories-button">
        <button className="all-categories-button" onClick={toggleCategories}>
          ☰ TOUTES CATÉGORIES 
        </button>

        {showCategories && (
          <div className="categories-dropdown">
            {categories.map((category, index) => (
              <div key={index} className="category-item">
                {category} <span className="arrow">{category !== "+ More Categories" ? '>' : ''}</span>
              </div>
            ))}
          </div>
        )}
      </div>

      <div className="carousel">
        <div className="carousel-inner" style={{ transform: `translateX(-${currentIndex * 100}%)` }}>
          {images.map((src, index) => (
            <div className="carousel-item" key={index}>
              <img src={src} alt={`Slide ${index + 1}`} className="carousel-image" />
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default CategoriesCarouselSection;
