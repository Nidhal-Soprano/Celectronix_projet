import React from 'react';
import './styles/Footer.css'; 

const Footer: React.FC = () => {
  return (
    <footer className="footer">
      {/* Partie haute : Livraison, Paiement, Confiance, Help Center */}
      <div className="footer-top">
        <div className="footer-info">
          <img src="/images/delivery.png" alt="Livraison gratuite" />
          <h2>Livraison gratuite</h2>
          <p>La livraison est gratuite en 48h à partir de 300dt</p>
        </div>
        <div className="footer-info">
          <img src="/images/payment.png" alt="Paiement sécurisé" />
          <h2>Paiement sécurisé</h2>
          <p>Payez avec les méthodes de paiement les plus populaires et sécurisées au monde.</p>
        </div>
        <div className="footer-info">
          <img src="/images/trust.png" alt="Achat en confiance" />
          <h2>Achetez en toute confiance</h2>
          <p>Notre protection d'acheteur couvre votre achat du clic à la livraison.</p>
        </div>
        <div className="footer-info">
          <img src="/images/help.png" alt="Help Center" />
          <h2>24/7 Help Center</h2>
          <p>Avoir une question ? Appellez un spécialiste 71 427 461</p>
        </div>
      </div>
      <div className="footer-separator-alternate"></div>

      <div className="footer-bottom">
        <div className="footer-logo-section">
          <img src="/images/logo.jpg" alt="CELECTRONIX" className="footer-logo" />
          <div className="text">
          <p><strong>Adresse:</strong> Centre Said Avenue Habib Bourguiba, Mégrine</p>
          <p><strong>Tél:</strong> +216 71 427 461</p>
          <p><strong>Fax:</strong> +216 79 325 792</p>
          <p><strong>Email:</strong> contact@celectronix.com</p>
          </div>
        </div>

        <div className="footer-links">
          <h3 className="products-title">Produits</h3>
            <div className="products-group">
                  <ul className="products-list">
                    <li className="product-item">Promotions</li>
                    <li className="product-item">Nouveaux produits</li>
                    <li className="product-item">Meilleures ventes</li>
                  </ul>
            </div>
        </div>

        <div className="footer-links">
          <h4>Notre Société</h4>
          <ul>
            <li><a href=''>Livraison</a></li>
            <li><a href=''>Conditions d'utilisation</a></li>
            <li><a href=''>À propos</a></li>
            <li><a href=''>Paiement sécurisé</a></li>
            <li><a href=''>Contactez-nous</a></li>
            <li><a href=''>Plan du site</a></li>
            <li><a href=''>Magasins</a></li>
          </ul>
        </div>

        <div className="footer-social">
          <h4>Suivez-nous</h4>
          <div className="social-icons">
  <a className="social-button google" href="#" title="Google">
    <i className="fa fa-google-plus"></i>
  </a>
  <a className="social-button facebook" href="#" title="Facebook">
    <i className="fa fa-facebook"></i>
  </a>
  <a className="social-button youtube" href="#" title="YouTube">
    <i className="fa fa-youtube"></i>
  </a>
</div>

<div className="newsletter">
      <h4 className="section-title">Rejoignez Notre Newsletter</h4>
      <div className="newsletter-input">
        <input 
          type="email" 
          placeholder="Votre adresse e-mail" 
          aria-label="Adresse e-mail pour newsletter"
        />
        <button className="subscribe-btn">S'ABONNER</button>
      </div>
    </div>
  </div>
</div>
<div className="footer-separator-alternate"></div>
      {/* Footer Bottom Section */}
{/* Footer Bottom Section */}
<div className="footer-bottom-2">
  <div className="payment-methods">
    <img src="/images/visa.png" alt="Méthodes de paiement" />
  </div>
  <div className="copyright">
    Copyright © 2019 CELECTRONIX. All Rights Reserved
  </div>
</div>


    </footer>
  );
};

export default Footer;
