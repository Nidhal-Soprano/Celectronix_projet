import React from 'react';
import './styles/Header.css'; 
import { FiChevronDown , FiSearch} from 'react-icons/fi';
import { PiShoppingBagOpenFill } from 'react-icons/pi';


const Header: React.FC = () => {
  return (
    <header className="header">
      <div className="top-connexion">
        <div className="connexion">
          Connexion <FiChevronDown />
        </div>
        </div>

      <div className="main-header">
        <div className="logo">
          <img src="./images/logo.jpg" alt="Celectronix" />
        </div>
        <div className="search-bar">
          <select className="category-select">
            <option>Toutes</option>
          </select>
          <input type="text" placeholder="Rechercher un produit, une marque, une référence..." />
          <button className="search-button"><FiSearch className="search-icon" /></button>
        </div>

        <div className="cart">
  <span className="cart-count">0</span>
  <div className="cart-content">
  <PiShoppingBagOpenFill className="cart-icon" />
        <span className="cart-price">0.000 TND</span>
    <FiChevronDown className="cart-chevron" />
  </div>
</div>
      </div>

      {/* Section 3 : Navbar */}
      <nav className="menu-bar">
        <a href="#">ACCUEIL</a>
        <a href="#">NOUVEAUX PRODUITS</a>
        <a href="#">PROMOTIONS</a>
        <a href="#">NOS MAGASINS</a>
        <a href="#">ALL MANUFACTURERS</a>
      </nav>
    </header>
  );
};

export default Header;
