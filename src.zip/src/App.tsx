import React from 'react';
import Header from './components/Header'; 
import './App.css';
import CategoriesCarouselSection from './components/CategoriesCarouselSection';
import Footer from './components/Footer';
import ProductsPage from './components/ProductsPage';

const App: React.FC = () => {
  return (
    <div className="App">
      <Header />
      <CategoriesCarouselSection />
      <ProductsPage />
      <Footer />
    </div>
  );
};

export default App;
